/*
 * LeetCode 342. Power of Four
 * Link: https://leetcode.com/problems/power-of-four/
 *
 * Approach: Power of two AND its single set bit sits at an even position: n & 0x55555555 != 0.
 * Time:  O(1)
 * Space: O(1)
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

bool isPowerOfFour(int n) {
    return n > 0 && (n & (n - 1)) == 0 && (n & 0x55555555) != 0;
}
