/*
 * LeetCode 137. Single Number II
 * Link: https://leetcode.com/problems/single-number-ii/
 *
 * Approach: Track bits seen once (ones) and twice (twos) with bitmasks; a bit seen three times is cleared from both.
 * Time:  O(n)
 * Space: O(1)
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

int singleNumber(int* nums, int numsSize) {
    int ones = 0, twos = 0;
    for (int i = 0; i < numsSize; i++) {
        ones = (ones ^ nums[i]) & ~twos;
        twos = (twos ^ nums[i]) & ~ones;
    }
    return ones;
}
