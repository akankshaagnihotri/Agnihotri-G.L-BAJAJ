/*
 * LeetCode 762. Prime Number of Set Bits in Binary Representation
 * Link: https://leetcode.com/problems/prime-number-of-set-bits-in-binary-representation/
 *
 * Approach: right <= 10^6 < 2^20, so set-bit count is at most 20. Precompute primes <= 20 as a bitmask (665772) and test membership.
 * Time:  O(right - left)
 * Space: O(1)
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

int countPrimeSetBits(int left, int right) {
    // bits 2,3,5,7,11,13,17,19 set -> primes up to 20
    const int PRIME_MASK = 665772;
    int ans = 0;
    for (int i = left; i <= right; i++) {
        int bits = __builtin_popcount(i);
        if ((PRIME_MASK >> bits) & 1) ans++;
    }
    return ans;
}
