/*
 * LeetCode 2220. Minimum Bit Flips to Convert Number
 * Link: https://leetcode.com/problems/minimum-bit-flips-to-convert-number/
 *
 * Approach: Bits to flip = number of differing bits = popcount(start ^ goal).
 * Time:  O(1)
 * Space: O(1)
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

int minBitFlips(int start, int goal) {
    unsigned int diff = (unsigned int)(start ^ goal);
    int count = 0;
    while (diff) {
        diff &= (diff - 1);
        count++;
    }
    return count;
}
