# Bit-Manipulation-Assignment (C)

LeetCode Bit Manipulation assignment solutions in C (all 29 problems, tested).

| # | Problem | Solution | Link |
|---|---------|----------|------|
| 191 | Number of 1 Bits | [0191-Number-of-1-Bits.c](0191-Number-of-1-Bits.c) | [LeetCode](https://leetcode.com/problems/number-of-1-bits/) |
| 338 | Counting Bits | [0338-Counting-Bits.c](0338-Counting-Bits.c) | [LeetCode](https://leetcode.com/problems/counting-bits/) |
| 405 | Convert a Number to Hexadecimal | [0405-Convert-a-Number-to-Hexadecimal.c](0405-Convert-a-Number-to-Hexadecimal.c) | [LeetCode](https://leetcode.com/problems/convert-a-number-to-hexadecimal/) |
| 762 | Prime Number of Set Bits in Binary Representation | [0762-Prime-Number-of-Set-Bits-in-Binary-Representation.c](0762-Prime-Number-of-Set-Bits-in-Binary-Representation.c) | [LeetCode](https://leetcode.com/problems/prime-number-of-set-bits-in-binary-representation/) |
| 868 | Binary Gap | [0868-Binary-Gap.c](0868-Binary-Gap.c) | [LeetCode](https://leetcode.com/problems/binary-gap/) |
| 1342 | Number of Steps to Reduce a Number to Zero | [1342-Number-of-Steps-to-Reduce-a-Number-to-Zero.c](1342-Number-of-Steps-to-Reduce-a-Number-to-Zero.c) | [LeetCode](https://leetcode.com/problems/number-of-steps-to-reduce-a-number-to-zero/) |
| 231 | Power of Two | [0231-Power-of-Two.c](0231-Power-of-Two.c) | [LeetCode](https://leetcode.com/problems/power-of-two/) |
| 342 | Power of Four | [0342-Power-of-Four.c](0342-Power-of-Four.c) | [LeetCode](https://leetcode.com/problems/power-of-four/) |
| 476 | Number Complement | [0476-Number-Complement.c](0476-Number-Complement.c) | [LeetCode](https://leetcode.com/problems/number-complement/) |
| 693 | Binary Number with Alternating Bits | [0693-Binary-Number-with-Alternating-Bits.c](0693-Binary-Number-with-Alternating-Bits.c) | [LeetCode](https://leetcode.com/problems/binary-number-with-alternating-bits/) |
| 1009 | Complement of Base 10 Integer | [1009-Complement-of-Base-10-Integer.c](1009-Complement-of-Base-10-Integer.c) | [LeetCode](https://leetcode.com/problems/complement-of-base-10-integer/) |
| 89 | Gray Code | [0089-Gray-Code.c](0089-Gray-Code.c) | [LeetCode](https://leetcode.com/problems/gray-code/) |
| 190 | Reverse Bits | [0190-Reverse-Bits.c](0190-Reverse-Bits.c) | [LeetCode](https://leetcode.com/problems/reverse-bits/) |
| 201 | Bitwise AND of Numbers Range | [0201-Bitwise-AND-of-Numbers-Range.c](0201-Bitwise-AND-of-Numbers-Range.c) | [LeetCode](https://leetcode.com/problems/bitwise-and-of-numbers-range/) |
| 318 | Maximum Product of Word Lengths | [0318-Maximum-Product-of-Word-Lengths.c](0318-Maximum-Product-of-Word-Lengths.c) | [LeetCode](https://leetcode.com/problems/maximum-product-of-word-lengths/) |
| 371 | Sum of Two Integers | [0371-Sum-of-Two-Integers.c](0371-Sum-of-Two-Integers.c) | [LeetCode](https://leetcode.com/problems/sum-of-two-integers/) |
| 1318 | Minimum Flips to Make a OR b Equal to c | [1318-Minimum-Flips-to-Make-a-OR-b-Equal-to-c.c](1318-Minimum-Flips-to-Make-a-OR-b-Equal-to-c.c) | [LeetCode](https://leetcode.com/problems/minimum-flips-to-make-a-or-b-equal-to-c/) |
| 136 | Single Number | [0136-Single-Number.c](0136-Single-Number.c) | [LeetCode](https://leetcode.com/problems/single-number/) |
| 137 | Single Number II | [0137-Single-Number-II.c](0137-Single-Number-II.c) | [LeetCode](https://leetcode.com/problems/single-number-ii/) |
| 260 | Single Number III | [0260-Single-Number-III.c](0260-Single-Number-III.c) | [LeetCode](https://leetcode.com/problems/single-number-iii/) |
| 268 | Missing Number | [0268-Missing-Number.c](0268-Missing-Number.c) | [LeetCode](https://leetcode.com/problems/missing-number/) |
| 389 | Find the Difference | [0389-Find-the-Difference.c](0389-Find-the-Difference.c) | [LeetCode](https://leetcode.com/problems/find-the-difference/) |
| 461 | Hamming Distance | [0461-Hamming-Distance.c](0461-Hamming-Distance.c) | [LeetCode](https://leetcode.com/problems/hamming-distance/) |
| 2220 | Minimum Bit Flips to Convert Number | [2220-Minimum-Bit-Flips-to-Convert-Number.c](2220-Minimum-Bit-Flips-to-Convert-Number.c) | [LeetCode](https://leetcode.com/problems/minimum-bit-flips-to-convert-number/) |
| 982 | Triples with Bitwise AND Equal To Zero | [0982-Triples-with-Bitwise-AND-Equal-To-Zero.c](0982-Triples-with-Bitwise-AND-Equal-To-Zero.c) | [LeetCode](https://leetcode.com/problems/triples-with-bitwise-and-equal-to-zero/) |
| 1458 | Max Dot Product of Two Subsequences | [1458-Max-Dot-Product-of-Two-Subsequences.c](1458-Max-Dot-Product-of-Two-Subsequences.c) | [LeetCode](https://leetcode.com/problems/max-dot-product-of-two-subsequences/) |
| 1611 | Minimum One Bit Operations to Make Integers Zero | [1611-Minimum-One-Bit-Operations-to-Make-Integers-Zero.c](1611-Minimum-One-Bit-Operations-to-Make-Integers-Zero.c) | [LeetCode](https://leetcode.com/problems/minimum-one-bit-operations-to-make-integers-zero/) |
| 1863 | Sum of All Subset XOR Totals | [1863-Sum-of-All-Subset-XOR-Totals.c](1863-Sum-of-All-Subset-XOR-Totals.c) | [LeetCode](https://leetcode.com/problems/sum-of-all-subset-xor-totals/) |
| 914 | X of a Kind in a Deck of Cards | [0914-X-of-a-Kind-in-a-Deck-of-Cards.c](0914-X-of-a-Kind-in-a-Deck-of-Cards.c) | [LeetCode](https://leetcode.com/problems/x-of-a-kind-in-a-deck-of-cards/) |
