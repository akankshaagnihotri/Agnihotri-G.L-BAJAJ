/*
 * LeetCode 982. Triples with Bitwise AND Equal To Zero
 * Link: https://leetcode.com/problems/triples-with-bitwise-and-equal-to-zero/
 *
 * Approach: Count frequency of every pair AND value (values < 2^16). For each third element k, add counts of all pair-values that are subsets of ~k.
 * Time:  O(n^2 + n * 2^16)
 * Space: O(2^16)
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

int countTriplets(int* nums, int numsSize) {
    const int FULL = (1 << 16) - 1;
    int* cnt = (int*)calloc(1 << 16, sizeof(int));
    for (int i = 0; i < numsSize; i++)
        for (int j = 0; j < numsSize; j++)
            cnt[nums[i] & nums[j]]++;

    int ans = 0;
    for (int i = 0; i < numsSize; i++) {
        int comp = FULL ^ nums[i];                      // bits where nums[i] is 0
        for (int s = comp; ; s = (s - 1) & comp) {      // iterate all subsets of comp
            ans += cnt[s];
            if (s == 0) break;
        }
    }
    free(cnt);
    return ans;
}
