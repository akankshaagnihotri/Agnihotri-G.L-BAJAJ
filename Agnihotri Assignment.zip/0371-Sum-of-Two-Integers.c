/*
 * LeetCode 371. Sum of Two Integers
 * Link: https://leetcode.com/problems/sum-of-two-integers/
 *
 * Approach: XOR gives sum without carry, (a & b) << 1 gives the carry; repeat until carry is 0. Use unsigned to avoid signed-overflow UB.
 * Time:  O(32) = O(1)
 * Space: O(1)
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

int getSum(int a, int b) {
    unsigned int x = (unsigned int)a, y = (unsigned int)b;
    while (y) {
        unsigned int carry = (x & y) << 1;
        x ^= y;
        y = carry;
    }
    return (int)x;
}
