/*
 * LeetCode 476. Number Complement
 * Link: https://leetcode.com/problems/number-complement/
 *
 * Approach: Build a mask of all 1s covering num's bit length, then XOR with num.
 * Time:  O(log n)
 * Space: O(1)
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

int findComplement(int num) {
    unsigned int mask = ~0u;
    while (mask & (unsigned int)num) mask <<= 1;   // zeros exactly where num has bits
    return (int)(~mask & ~(unsigned int)num);
}
