/*
 * LeetCode 136. Single Number
 * Link: https://leetcode.com/problems/single-number/
 *
 * Approach: XOR of all elements: pairs cancel (x ^ x = 0), leaving the single one.
 * Time:  O(n)
 * Space: O(1)
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

int singleNumber(int* nums, int numsSize) {
    int res = 0;
    for (int i = 0; i < numsSize; i++) res ^= nums[i];
    return res;
}
