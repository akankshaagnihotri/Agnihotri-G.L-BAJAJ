/*
 * LeetCode 191. Number of 1 Bits
 * Link: https://leetcode.com/problems/number-of-1-bits/
 *
 * Approach: Brian Kernighan's trick: n & (n-1) clears the lowest set bit, so loop once per set bit.
 * Time:  O(k), k = number of set bits
 * Space: O(1)
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

int hammingWeight(uint32_t n) {
    int count = 0;
    while (n) {
        n &= (n - 1);   // drop lowest set bit
        count++;
    }
    return count;
}
