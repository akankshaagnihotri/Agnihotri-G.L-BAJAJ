/*
 * LeetCode 389. Find the Difference
 * Link: https://leetcode.com/problems/find-the-difference/
 *
 * Approach: XOR all characters of s and t; matching letters cancel, leaving the added one.
 * Time:  O(n)
 * Space: O(1)
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

char findTheDifference(char* s, char* t) {
    char res = 0;
    for (int i = 0; s[i]; i++) res ^= s[i];
    for (int i = 0; t[i]; i++) res ^= t[i];
    return res;
}
