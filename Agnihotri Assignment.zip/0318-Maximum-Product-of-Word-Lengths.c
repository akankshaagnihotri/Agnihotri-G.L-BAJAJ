/*
 * LeetCode 318. Maximum Product of Word Lengths
 * Link: https://leetcode.com/problems/maximum-product-of-word-lengths/
 *
 * Approach: Encode each word as a 26-bit letter mask; two words share no letters iff masks AND to 0.
 * Time:  O(n^2 + total chars)
 * Space: O(n)
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

int maxProduct(char** words, int wordsSize) {
    int* mask = (int*)calloc(wordsSize, sizeof(int));
    int* len = (int*)malloc(wordsSize * sizeof(int));
    for (int i = 0; i < wordsSize; i++) {
        len[i] = (int)strlen(words[i]);
        for (int k = 0; k < len[i]; k++) {
            mask[i] |= 1 << (words[i][k] - 'a');
        }
    }
    int best = 0;
    for (int i = 0; i < wordsSize; i++) {
        for (int j = i + 1; j < wordsSize; j++) {
            if ((mask[i] & mask[j]) == 0 && len[i] * len[j] > best) {
                best = len[i] * len[j];
            }
        }
    }
    free(mask);
    free(len);
    return best;
}
