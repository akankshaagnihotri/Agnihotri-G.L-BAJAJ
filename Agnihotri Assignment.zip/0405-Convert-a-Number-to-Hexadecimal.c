/*
 * LeetCode 405. Convert a Number to Hexadecimal
 * Link: https://leetcode.com/problems/convert-a-number-to-hexadecimal/
 *
 * Approach: Treat num as unsigned 32-bit (handles two's complement for negatives), extract 4 bits at a time.
 * Time:  O(1) (at most 8 digits)
 * Space: O(1)
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

char* toHex(int num) {
    char* res = (char*)malloc(9);          // max 8 hex digits + '\0'
    if (num == 0) {
        strcpy(res, "0");
        return res;
    }
    unsigned int x = (unsigned int)num;    // two's complement for negatives
    const char* digits = "0123456789abcdef";
    char buf[9];
    int len = 0;
    while (x) {
        buf[len++] = digits[x & 15];
        x >>= 4;
    }
    for (int i = 0; i < len; i++) res[i] = buf[len - 1 - i];
    res[len] = '\0';
    return res;
}
