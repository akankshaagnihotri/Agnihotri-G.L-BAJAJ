/*
 * LeetCode 914. X of a Kind in a Deck of Cards
 * Link: https://leetcode.com/problems/x-of-a-kind-in-a-deck-of-cards/
 *
 * Approach: Count each card value; a valid X >= 2 exists iff the GCD of all counts is >= 2.
 * Time:  O(n)
 * Space: O(n)
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

static int gcd(int a, int b) {
    while (b) {
        int t = a % b;
        a = b;
        b = t;
    }
    return a;
}

bool hasGroupsSizeX(int* deck, int deckSize) {
    int* freq = (int*)calloc(10000, sizeof(int));   // card values are in [0, 10^4)
    for (int i = 0; i < deckSize; i++) freq[deck[i]]++;
    int g = 0;
    for (int v = 0; v < 10000; v++) {
        if (freq[v]) g = gcd(g, freq[v]);
    }
    free(freq);
    return g >= 2;
}
