/*
 * LeetCode 1009. Complement of Base 10 Integer
 * Link: https://leetcode.com/problems/complement-of-base-10-integer/
 *
 * Approach: Same as Number Complement; special-case n = 0 whose complement is 1.
 * Time:  O(log n)
 * Space: O(1)
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

int bitwiseComplement(int n) {
    if (n == 0) return 1;
    unsigned int mask = ~0u;
    while (mask & (unsigned int)n) mask <<= 1;
    return (int)(~mask & ~(unsigned int)n);
}
