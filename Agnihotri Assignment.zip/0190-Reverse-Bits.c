/*
 * LeetCode 190. Reverse Bits
 * Link: https://leetcode.com/problems/reverse-bits/
 *
 * Approach: Take the lowest bit of n 32 times and push it into result from the left.
 * Time:  O(32) = O(1)
 * Space: O(1)
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

uint32_t reverseBits(uint32_t n) {
    uint32_t res = 0;
    for (int i = 0; i < 32; i++) {
        res = (res << 1) | (n & 1);
        n >>= 1;
    }
    return res;
}
