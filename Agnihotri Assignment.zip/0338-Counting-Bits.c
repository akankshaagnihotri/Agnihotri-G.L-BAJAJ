/*
 * LeetCode 338. Counting Bits
 * Link: https://leetcode.com/problems/counting-bits/
 *
 * Approach: DP on bits: bits(i) = bits(i >> 1) + (i & 1).
 * Time:  O(n)
 * Space: O(n) (output)
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

int* countBits(int n, int* returnSize) {
    *returnSize = n + 1;
    int* dp = (int*)calloc(n + 1, sizeof(int));
    for (int i = 1; i <= n; i++) {
        dp[i] = dp[i >> 1] + (i & 1);
    }
    return dp;
}
