/*
 * LeetCode 461. Hamming Distance
 * Link: https://leetcode.com/problems/hamming-distance/
 *
 * Approach: Number of differing bits = popcount(x ^ y).
 * Time:  O(1)
 * Space: O(1)
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

int hammingDistance(int x, int y) {
    unsigned int diff = (unsigned int)(x ^ y);
    int count = 0;
    while (diff) {
        diff &= (diff - 1);
        count++;
    }
    return count;
}
