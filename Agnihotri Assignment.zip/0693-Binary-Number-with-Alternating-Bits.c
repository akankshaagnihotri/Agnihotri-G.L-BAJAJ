/*
 * LeetCode 693. Binary Number with Alternating Bits
 * Link: https://leetcode.com/problems/binary-number-with-alternating-bits/
 *
 * Approach: x = n ^ (n >> 1) is all 1s iff bits alternate; all-1s number satisfies x & (x+1) == 0.
 * Time:  O(1)
 * Space: O(1)
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

bool hasAlternatingBits(int n) {
    unsigned int x = (unsigned int)n ^ ((unsigned int)n >> 1);
    return (x & (x + 1)) == 0;
}
