/*
 * LeetCode 260. Single Number III
 * Link: https://leetcode.com/problems/single-number-iii/
 *
 * Approach: XOR of all = a ^ b. Pick any set bit (lowest) of it to split numbers into two groups; XOR each group to get a and b.
 * Time:  O(n)
 * Space: O(1)
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

int* singleNumber(int* nums, int numsSize, int* returnSize) {
    long long xr = 0;
    for (int i = 0; i < numsSize; i++) xr ^= nums[i];
    long long lowbit = xr & -xr;   // long long avoids INT_MIN overflow
    int a = 0, b = 0;
    for (int i = 0; i < numsSize; i++) {
        if (nums[i] & lowbit) a ^= nums[i];
        else b ^= nums[i];
    }
    int* res = (int*)malloc(2 * sizeof(int));
    res[0] = a;
    res[1] = b;
    *returnSize = 2;
    return res;
}
