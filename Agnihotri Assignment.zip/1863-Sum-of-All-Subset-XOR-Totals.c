/*
 * LeetCode 1863. Sum of All Subset XOR Totals
 * Link: https://leetcode.com/problems/sum-of-all-subset-xor-totals/
 *
 * Approach: Each bit set in the OR of all numbers appears in exactly half (2^(n-1)) of the subset XORs, so answer = (OR of all) * 2^(n-1).
 * Time:  O(n)
 * Space: O(1)
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

int subsetXORSum(int* nums, int numsSize) {
    int orAll = 0;
    for (int i = 0; i < numsSize; i++) orAll |= nums[i];
    return orAll << (numsSize - 1);
}
