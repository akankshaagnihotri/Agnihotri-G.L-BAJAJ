/*
 * LeetCode 231. Power of Two
 * Link: https://leetcode.com/problems/power-of-two/
 *
 * Approach: A power of two has exactly one set bit, so n & (n-1) == 0 (and n > 0).
 * Time:  O(1)
 * Space: O(1)
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

bool isPowerOfTwo(int n) {
    return n > 0 && (n & (n - 1)) == 0;
}
