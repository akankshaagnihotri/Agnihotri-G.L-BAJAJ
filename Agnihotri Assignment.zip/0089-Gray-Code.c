/*
 * LeetCode 89. Gray Code
 * Link: https://leetcode.com/problems/gray-code/
 *
 * Approach: The i-th Gray code is i ^ (i >> 1).
 * Time:  O(2^n)
 * Space: O(2^n) (output)
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

int* grayCode(int n, int* returnSize) {
    int size = 1 << n;
    *returnSize = size;
    int* res = (int*)malloc(size * sizeof(int));
    for (int i = 0; i < size; i++) {
        res[i] = i ^ (i >> 1);
    }
    return res;
}
