/*
 * LeetCode 268. Missing Number
 * Link: https://leetcode.com/problems/missing-number/
 *
 * Approach: XOR all indices 0..n with all values; everything cancels except the missing number.
 * Time:  O(n)
 * Space: O(1)
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

int missingNumber(int* nums, int numsSize) {
    int res = numsSize;
    for (int i = 0; i < numsSize; i++) {
        res ^= i ^ nums[i];
    }
    return res;
}
