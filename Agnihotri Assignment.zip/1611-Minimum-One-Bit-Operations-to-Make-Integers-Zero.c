/*
 * LeetCode 1611. Minimum One Bit Operations to Make Integers Zero
 * Link: https://leetcode.com/problems/minimum-one-bit-operations-to-make-integers-zero/
 *
 * Approach: The answer is the index of n in the Gray code sequence, i.e. the inverse Gray code: XOR of n with all its right shifts.
 * Time:  O(log n)
 * Space: O(1)
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

int minimumOneBitOperations(int n) {
    int res = 0;
    while (n) {
        res ^= n;
        n >>= 1;
    }
    return res;
}
