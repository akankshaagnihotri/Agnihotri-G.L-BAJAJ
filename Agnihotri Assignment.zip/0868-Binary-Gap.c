/*
 * LeetCode 868. Binary Gap
 * Link: https://leetcode.com/problems/binary-gap/
 *
 * Approach: Scan bits; remember the position of the previous 1 and update the max distance at each new 1.
 * Time:  O(log n)
 * Space: O(1)
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

int binaryGap(int n) {
    int last = -1, best = 0;
    for (int i = 0; n > 0; i++, n >>= 1) {
        if (n & 1) {
            if (last != -1 && i - last > best) best = i - last;
            last = i;
        }
    }
    return best;
}
