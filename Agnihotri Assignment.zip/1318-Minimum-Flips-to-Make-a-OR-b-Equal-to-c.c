/*
 * LeetCode 1318. Minimum Flips to Make a OR b Equal to c
 * Link: https://leetcode.com/problems/minimum-flips-to-make-a-or-b-equal-to-c/
 *
 * Approach: Check bit by bit: if c bit is 1 need at least one of a,b set (1 flip if both 0); if c bit is 0 every set bit of a and b must be flipped.
 * Time:  O(30) = O(1)
 * Space: O(1)
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

int minFlips(int a, int b, int c) {
    int flips = 0;
    for (int i = 0; i < 31; i++) {
        int x = (a >> i) & 1, y = (b >> i) & 1, z = (c >> i) & 1;
        if (z == 1) {
            if (!(x | y)) flips++;
        } else {
            flips += x + y;
        }
    }
    return flips;
}
