/*
 * LeetCode 1458. Max Dot Product of Two Subsequences
 * Link: https://leetcode.com/problems/max-dot-product-of-two-subsequences/
 *
 * Approach: dp[i][j] = best non-empty dot product using nums1[:i], nums2[:j]. Either take the pair, extend previous best, or skip an element.
 * Time:  O(n * m)
 * Space: O(n * m)
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

int maxDotProduct(int* nums1, int nums1Size, int* nums2, int nums2Size) {
    int n = nums1Size, m = nums2Size;
    const int NEG = INT_MIN / 2;
    int* dp = (int*)malloc((n + 1) * (m + 1) * sizeof(int));
    for (int i = 0; i <= n; i++)
        for (int j = 0; j <= m; j++)
            dp[i * (m + 1) + j] = NEG;

    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            int prod = nums1[i - 1] * nums2[j - 1];
            int diag = dp[(i - 1) * (m + 1) + (j - 1)];
            int best = prod;
            if (diag > 0 && prod + diag > best) best = prod + diag;   // extend previous
            if (dp[(i - 1) * (m + 1) + j] > best) best = dp[(i - 1) * (m + 1) + j];  // skip nums1[i-1]
            if (dp[i * (m + 1) + (j - 1)] > best) best = dp[i * (m + 1) + (j - 1)];  // skip nums2[j-1]
            dp[i * (m + 1) + j] = best;
        }
    }
    int ans = dp[n * (m + 1) + m];
    free(dp);
    return ans;
}
