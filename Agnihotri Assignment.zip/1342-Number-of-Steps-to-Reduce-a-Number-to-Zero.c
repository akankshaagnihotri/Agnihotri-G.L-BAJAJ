/*
 * LeetCode 1342. Number of Steps to Reduce a Number to Zero
 * Link: https://leetcode.com/problems/number-of-steps-to-reduce-a-number-to-zero/
 *
 * Approach: Even -> shift right (1 step), odd -> subtract 1 (clear last bit, 1 step).
 * Time:  O(log n)
 * Space: O(1)
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

int numberOfSteps(int num) {
    int steps = 0;
    while (num > 0) {
        if (num & 1) num -= 1;
        else num >>= 1;
        steps++;
    }
    return steps;
}
